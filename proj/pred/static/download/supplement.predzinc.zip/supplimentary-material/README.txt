1 closeZnPro1-5.txt
  A list of all 235 protein chains (and their residues) that bind to zinc.

2 closeZnPro3-5.txt
  A list of all 210 protein chains (and their residues) that bind to Zn3, Zn4
  or Zn5. Zn3, Zn4 and Zn5 are Zn atoms that bind to 3, 4 and 5 amino acid residues
  respectively.

3 closeZnManuallyCurated.txt
  A list of 8 manually curated zinc-binding proteins (and their residues).

4 passe.idlist.txt
  Chain identifiers for 2,727 unique protein chains.

5 background_amino_acid_frequency.txt
  Background amino acid composition for 20 amino acids.

6 matrices-for-encoding.txt
  Matrices for encoding different parameters for generating SVM features
  vectors.

7 encoding-single-site-vector-pair-based-vector.doc
  Description for encoding single-site vectors and pair-based vectors

8 supplementary-figures.doc
  Supplementary figures:
  Figure 1: Illustration about how to encode a single-site vector and a pair-based vector
  Figure 2: Fraction of conserved zinc-binding residues out of all zinc-binding residues and (b) Fraction of conserved residues out of all residues cutting at different conservation score levels for Cys, His, Asp and Glu separately. 
  Figure 3: Dot plot for the sequence number of the central residue of matched nine-residue segments between (a) 1EG9A (449 amino acids) and 1FQTA (112 amino acids) and (b) 1FLGA (582 amino acids) and 1GYCA (499 amino acids). 
  Figure 4: Zinc-binding sites of liver alcohol dehydrogenase-NADH complex (PDB code 2OHX)
  Figure 5: An example of a protein that possibly does bind zinc in vivo, although no zinc was present in the crystals. 

References:

  Nanjiang Shu, Tuping Zhou and Sven Hovm�ller, "Prediction of Zinc-Binding
  Sites in Proteins From Sequence"

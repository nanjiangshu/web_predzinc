int i_min ( int i1, int i2 );
int i_max ( int i1, int i2 );
int combin2 ( int n, int k );
void ivec_indicator ( int n, int a[] );
void ksub_next ( int n, int k, int a[], bool *more );
void ksub_next2 ( int n, int k, int a[], int *in, int *iout );
void ksub_next3 ( int n, int k, int a[], bool *more, int *in, int *iout );
void ksub_next4 ( int n, int k, int a[], bool *done );

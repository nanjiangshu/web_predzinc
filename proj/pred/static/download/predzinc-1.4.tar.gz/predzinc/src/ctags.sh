#!/bin/bash
/usr/bin/ctags *.{h,cpp} 
